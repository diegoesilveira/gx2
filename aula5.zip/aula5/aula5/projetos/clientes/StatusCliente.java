package aula5.projetos.clientes;

public enum StatusCliente {
	
	ATIVO,
	INATIVO,
	BLOQUEADO;

}
