package aula5.projetos.teste;

import aula5.projetos.planos.telefonia.PlanoPosTelefonia;

public class TestePlanoPosInternet {
	
	public static void main(String[] args) {
		
	
		
		
		
	}

}
