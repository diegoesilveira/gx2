package aula5.projetos.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import aula5.projetos.clientes.Cidade;
import aula5.projetos.clientes.Cliente;
import aula5.projetos.clientes.StatusCliente;
import aula5.projetos.planos.internet.PlanoPosInternet;
import aula5.projetos.planos.internet.PlanoPreInternet;
import aula5.projetos.planos.telefonia.PlanoPosTelefonia;
import aula5.projetos.planos.telefonia.PlanoPreTelefonia;
import aula5.projetos.planos.tv.PlanoTvBasico;
import aula5.projetos.planos.tv.PlanoTvBasicoFilme;
import aula5.projetos.planos.tv.PlanoTvFull;

public class SolicitaDadosCliente {
	double valorTotalFatura;
	ReciboClienteTxt geraArquivo = new ReciboClienteTxt();
	SimpleDateFormat formatadorData = new SimpleDateFormat("dd/MM/yyyy");

	public void entradaDadosCliente() {

		try (Scanner scanner = new Scanner(System.in)) {

			System.out.print("Digite seu nome: ");
			String nomeCliente = scanner.nextLine();

			System.out.print("Digite seu CPF: ");
			String cpfCliente = scanner.nextLine();

			System.out.print("Digite seu RG: ");
			String rgCliente = scanner.nextLine();

			System.out.print("Digite seu e-mail: ");
			String emailCliente = scanner.nextLine();

			System.out.print("Digite sua data de nascimento no formato DD/MM/AAAA: ");
			String dataNascimento = scanner.nextLine();
			Date dataNascimentoFormatada = formatadorData.parse(dataNascimento);

			System.out.print("Digite o Status: Ativo, Inativo ou Bloqueado: ");
			String status = scanner.nextLine().toUpperCase();

			System.out.println("Digite Endereco: ");
			String enderecoCliente = scanner.nextLine();

			System.out.println("Digite a Cidade: ");
			String cidadeNome = scanner.nextLine();

			System.out.println("Digite seu CEP: ");
			String cepCliente = scanner.nextLine();

			System.out.println("Digite seu telefone: ");
			String telefoneCliente = scanner.nextLine();

			Cliente cliente = new Cliente(nomeCliente, cpfCliente, rgCliente, emailCliente, dataNascimentoFormatada,
					StatusCliente.valueOf(status), enderecoCliente, new Cidade(cidadeNome), cepCliente,
					telefoneCliente);

			boolean sair = false;
			while (sair == false) {

				System.out.println(
						"\n-------------------------Escolha os pacotes disponiveis------------------------------------------\n");
				System.out.println(
						"1 - Plano Telefonia    2 - Plano Internet     3 - Plano TV     4 - Gerar Fatura    5 - Encerrar\n ");
				int escolhaPacotes = Integer.parseInt(scanner.nextLine());

				if (escolhaPacotes == 1) {
					System.out.println("Plano telefonia \n Escolha um plano 1 - Pre Pago  2 - Pos Pago");
					escolhaPacotes = Integer.parseInt(scanner.nextLine());

					if (escolhaPacotes == 1) {
						System.out.println("Escolhido Plano Telefonia Pre Pago");
						PlanoPreTelefonia planoPreTelefonia = new PlanoPreTelefonia();
						System.out.println("Valor do plano: " + planoPreTelefonia.getValorPlano());
						valorTotalFatura += planoPreTelefonia.getValorPlano();
					} else if (escolhaPacotes == 2) {
						PlanoPosTelefonia planoPosTelefonia = new PlanoPosTelefonia();
						System.out.println("Escolhido Plano Telefonia Pos Pago.");
						System.out.println("Valor do plano: " + planoPosTelefonia.getValorPlano());
						valorTotalFatura += planoPosTelefonia.getValorPlano();
					}
					continue;

				}

				else if (escolhaPacotes == 2) {
					System.out.println("Plano de Internet \n Escolha um plano 1 - Pre Pago  2 - Pos Pago");
					escolhaPacotes = Integer.parseInt(scanner.nextLine());

					if (escolhaPacotes == 1) {
						System.out.println("Escolhido Plano Internet Pre Pago");
						PlanoPreInternet planoPreInternet = new PlanoPreInternet();
						System.out.println("Escolhido plano de Internet Pre Pago.");
						System.out.println("Valor do plano: " + planoPreInternet.getValorPlano());
						valorTotalFatura += planoPreInternet.getValorPlano();

					} else if (escolhaPacotes == 2) {
						System.out.println("Escolhido Plano Internet Pos Pago");
						PlanoPosInternet planoPosInternet = new PlanoPosInternet();
						System.out.println("Escolhido plano de Internet Pre Pago.");
						System.out.println("Valor do plano: " + planoPosInternet.getValorPlano());
						valorTotalFatura += planoPosInternet.getValorPlano();

					}
					continue;

				} else if (escolhaPacotes == 3) {
					System.out.println(
							"Plano de TV  \n Escolha o pacote de TV   1 - Basico   2 - Basico + Filmes  3 - Full");
					escolhaPacotes = Integer.parseInt(scanner.nextLine());

					if (escolhaPacotes == 1) {
						System.out.println("Escolhido Plano TV Basico.");
						PlanoTvBasico planoTvBasico = new PlanoTvBasico();
						System.out.println("Escolhido plano de TV." + planoTvBasico.getDescricaoPlano());
						System.out.println("Valor do plano: " + planoTvBasico.getValorPlano());
						valorTotalFatura += planoTvBasico.getValorPlano();

					} else if (escolhaPacotes == 2) {
						System.out.println("Escolhido Plano TV Basico + Filmes.");
						PlanoTvBasicoFilme planoTvBasicoFilme = new PlanoTvBasicoFilme();
						System.out.println("Escolhido plano de TV." + planoTvBasicoFilme.getDescricaoPlano());
						System.out.println("Valor do plano: " + planoTvBasicoFilme.getValorPlano());
						valorTotalFatura += planoTvBasicoFilme.getValorPlano();

					} else if (escolhaPacotes == 3) {
						System.out.println("Escolhido Plano TV Full.");
						PlanoTvFull planoTvFull = new PlanoTvFull();
						System.out.println("Escolhido plano de TV." + planoTvFull.getDescricaoPlano());
						System.out.println("Valor do plano: " + planoTvFull.getValorPlano());
						valorTotalFatura += planoTvFull.getValorPlano();

					} else {
						System.out.println("Escolha o pacote correto.");
						continue;
					}

					continue;

				}

				else if (escolhaPacotes == 4) {
					System.out.println("Gerando fatura.......");
					break;
				}

				else if (escolhaPacotes == 5) {
					System.out.println("Encerrando");

					break;
				} else {
					System.out.println("Op��o incorreta.");
					continue;
				}

			}

			geraArquivo.gerarReciboCliente(nomeCliente, cpfCliente, rgCliente, emailCliente, dataNascimentoFormatada,
					StatusCliente.valueOf(status), enderecoCliente, new Cidade(cidadeNome), cepCliente, telefoneCliente,
					valorTotalFatura);

		} catch (InputMismatchException e) {
			System.out.println("Erro digite corretamente." + e);
		} catch (NumberFormatException e) {
			System.out.println("Erro verifique o valor digitado. " + e);
		} catch (ParseException e) {
			System.out.println("Erro digite a data corretamene DD/MM/AAAA.");
		}

	}

}
