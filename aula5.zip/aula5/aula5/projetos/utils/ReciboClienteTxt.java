package aula5.projetos.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import aula5.projetos.clientes.Cidade;
import aula5.projetos.clientes.Cliente;
import aula5.projetos.clientes.StatusCliente;


public class ReciboClienteTxt {

	File file = new File("fatura.txt");
	Cliente cliente = new Cliente();
	

	public void gerarReciboCliente(String nomeCliente, String cpfCliente, String rgCliente, String emailCliente, Date dataNascimento, StatusCliente status, String enderecoCliente, Cidade cidade, String cepCliente, String telefoneCliente, double valorTotalFatura) {

		try {
			BufferedWriter saida = new BufferedWriter(new FileWriter(file, false));

			saida.write("----------------------------------------Cliente------------------------------------------------------------------------\n");

			saida.write("Nome Cliente: " + nomeCliente + "\n");
			saida.write("CPF: " + cpfCliente + "\n");
			saida.write("RG: " + rgCliente + "\n");
			saida.write("E-mail: " + emailCliente + "\n");
			saida.write("Data Nascimento: " + dataNascimento + "\n");
			saida.write("Status: " + status + "\n");
			saida.write("Endere�o: " + enderecoCliente + "\n");
			saida.write("Cidade: " + cidade.getDescricaoCidade() + "\n");
			saida.write("CEP: " + cepCliente + "\n");
			saida.write("Telefone: " + telefoneCliente + "\n");

			saida.write("----------------------------------------Planos Ativos:--------------------------------------------------------------- \n");

//			saida.write("C�digo do plano: " + plano.getCodPlano() + "\n");
//			saida.write("Descri��o do plano: " + plano.getDescricaoPlano() + "\n");
//			saida.write("Valor do plano: " + plano.getValorPlano() + "\n");
//			saida.write("Franquia plano Telefonia Pre: " + plano.getFranquiaMinutos() + "\n");
//			saida.write("Bonus plano Telefonia Pre: " + plano.getBonus() + "\n");
			
			saida.write("-----------------------------------------------------------------------------------------------------------------------\n");
			saida.write("----------------------------------------Fatura a pagar:--------------------------------------------------------------- \n");
			saida.write("Valor a Pagar: " + valorTotalFatura + "\n");
			
			saida.flush();
			saida.close();

		} catch (IOException e) {
			System.out.println("Erro na criacao do arquivo." + e);
		}

	}

}
