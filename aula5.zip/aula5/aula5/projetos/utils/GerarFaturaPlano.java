package aula5.projetos.utils;


public class GerarFaturaPlano {
	
	public static void geraFaturaCliente() {
		
		
		
	}
	
	

}
