package aula5.projetos.utils;

import java.util.InputMismatchException;
import java.util.Scanner;

import aula5.projetos.planos.telefonia.PlanoPosTelefonia;
import aula5.projetos.planos.telefonia.PlanoPreTelefonia;


public class EscolhaPlanos {

	public void planosCliente(int planoNumero) {

		try (Scanner scanner = new Scanner(System.in)) {

			if (planoNumero == 1) {
				System.out.println(
						"-----------------------------------Plano telefonia--------------------------------------------");
				System.out.println("Escolha um tipo de plano: Digite  1 - Pre Pago   2 - Pos Pago   3 - Nenhum");
				int opcao = Integer.parseInt(scanner.nextLine());

				if (opcao == 1) {
					System.out.println("Plano Pre Pago escolhido.");
					PlanoPreTelefonia planoPreTelefonia = new PlanoPreTelefonia();
					
				} else if (opcao == 2) {
					System.out.println("Plano Pos Pago escolhido.");
					PlanoPosTelefonia planoPosTelefonia = new PlanoPosTelefonia();
				}
			}

			else if (planoNumero == 2) {
				System.out.println("Plano Internet");
			}

			else if (planoNumero == 3) {
				System.out.println("Plano TV");
			}
			

		} catch (InputMismatchException e) {
			System.out.println("Erro escolha uma op��o valida.");
		}

	}

}
