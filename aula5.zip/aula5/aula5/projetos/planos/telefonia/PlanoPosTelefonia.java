package aula5.projetos.planos.telefonia;

public class PlanoPosTelefonia extends PlanoTelefonia {

	private double minutoAdicional = 100;

	public PlanoPosTelefonia() {
		super(001, "Plano Pos Telefonia", 159.99, 150);
	}
	
	public PlanoPosTelefonia(int codPlano, String descricaoPlano, double valorPlano, int franquiaMinutos, double minutoAdicional) {
		super(codPlano, descricaoPlano, valorPlano, franquiaMinutos);
		this.minutoAdicional = minutoAdicional;
	}

	public double getMinutoAdicional() {
		return minutoAdicional;
	}

	public void setMinutoAdicional(double minutoAdicional) {
		this.minutoAdicional = minutoAdicional;
	}

	@Override
	public String toString() {
		return "PlanoPosTelefonia [minutoAdicional=" + minutoAdicional + ", getFranquiaMinutos()="
				+ getFranquiaMinutos() + ", getCodPlano()=" + getCodPlano() + ", getDescricaoPlano()="
				+ getDescricaoPlano() + ", getValorPlano()=" + getValorPlano() + "]";
	}

	
	
}
