package aula5.projetos.planos.telefonia;

public class PlanoPreTelefonia extends PlanoTelefonia {

	private int bonus = 500;

	public PlanoPreTelefonia() {
		super(002, "Plano Pre Telefonia", 29.99, 500);
	}
	

	public PlanoPreTelefonia(int codPlano, String descricaoPlano, double valorPlano, int franquiaMinutos, int bonus) {
		super(codPlano, descricaoPlano, valorPlano, franquiaMinutos);
		this.bonus = bonus;
	}

	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}


	@Override
	public String toString() {
		return "PlanoPreTelefonia [bonus=" + bonus + ", getFranquiaMinutos()=" + getFranquiaMinutos()
				+ ", getCodPlano()=" + getCodPlano() + ", getDescricaoPlano()=" + getDescricaoPlano()
				+ ", getValorPlano()=" + getValorPlano() + "]";
	}
	
	

}
