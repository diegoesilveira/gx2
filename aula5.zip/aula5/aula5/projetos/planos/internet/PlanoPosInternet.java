package aula5.projetos.planos.internet;

public class PlanoPosInternet extends PlanoInternet{
	
	private double dadosAdicionais = 100;

	public PlanoPosInternet() {
		super(4, "Plano Pos Internet", 188, 200, 150);
	}
	
	public PlanoPosInternet(int codPlano, String descricaoPlano, double valorPlano, int velocidade,
			int franquiaDeDados, double dadosAdicionais) {
		super(codPlano, descricaoPlano, valorPlano, velocidade, franquiaDeDados);
		this.dadosAdicionais = dadosAdicionais;
	}

	public double getDadosAdicionais() {
		return dadosAdicionais;
	}

	public void setDadosAdicionais(double dadosAdicionais) {
		this.dadosAdicionais = dadosAdicionais;
	}

	@Override
	public String toString() {
		return "PlanoPosInternet [dadosAdicionais=" + dadosAdicionais + ", getVelocidade()=" + getVelocidade()
				+ ", getFranquiaDeDados()=" + getFranquiaDeDados() + ", getCodPlano()=" + getCodPlano()
				+ ", getDescricaoPlano()=" + getDescricaoPlano() + ", getValorPlano()=" + getValorPlano() + "]";
	}
	
	
	

}
