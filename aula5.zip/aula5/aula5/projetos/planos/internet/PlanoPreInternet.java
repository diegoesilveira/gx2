package aula5.projetos.planos.internet;

public class PlanoPreInternet extends PlanoInternet {

	public PlanoPreInternet() {
		super(003, "Plano Pre Internet", 99.99, 100, 250);
	}

	public PlanoPreInternet(int codPlano, String descricaoPlano, double valorPlano, int velocidade,
			int franquiaDeDados) {
		super(codPlano, descricaoPlano, valorPlano, velocidade, franquiaDeDados);

	}
	
	@Override
	public String toString() {
		return "PlanoPreInternet [getVelocidade()=" + getVelocidade() + ", getFranquiaDeDados()=" + getFranquiaDeDados()
				+ ", getCodPlano()=" + getCodPlano() + ", getDescricaoPlano()=" + getDescricaoPlano()
				+ ", getValorPlano()=" + getValorPlano() + "]";
	}
	
	

}
