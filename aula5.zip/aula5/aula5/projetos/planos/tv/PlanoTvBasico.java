package aula5.projetos.planos.tv;

public class PlanoTvBasico extends PacoteTV{

	public PlanoTvBasico() {
		super(012, "Plano TV Basico.", 49.9, 35);
		
	}

	public PlanoTvBasico(int codPlano, String descricaoPlano, double valorPlano, int quantidadeDeCanais) {
		super(codPlano, descricaoPlano, valorPlano, quantidadeDeCanais);
		
	}
	
	

}
