package aula5.projetos.planos.tv;

public class PlanoTvFull extends PacoteTV{

	public PlanoTvFull() {
		super(0321, "Plano TV Full", 199.99, 400);
	}

	public PlanoTvFull(int codPlano, String descricaoPlano, double valorPlano, int quantidadeDeCanais) {
		super(codPlano, descricaoPlano, valorPlano, quantidadeDeCanais);
	}
	
	

}
