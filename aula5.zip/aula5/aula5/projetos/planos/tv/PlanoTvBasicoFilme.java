package aula5.projetos.planos.tv;

public class PlanoTvBasicoFilme extends PacoteTV{

	public PlanoTvBasicoFilme() {
		super(0123, "Plano TV Basico + Filme.", 79.90, 200);
	}

	public PlanoTvBasicoFilme(int codPlano, String descricaoPlano, double valorPlano, int quantidadeDeCanais) {
		super(codPlano, descricaoPlano, valorPlano, quantidadeDeCanais);
	}
	
	

}
