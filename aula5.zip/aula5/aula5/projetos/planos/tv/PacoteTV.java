package aula5.projetos.planos.tv;

public abstract class PacoteTV extends PlanoTv {
	
	private int quantidadeDeCanais;
	
	public PacoteTV() {
	}

	public PacoteTV(int codPlano, String descricaoPlano, double valorPlano, int quantidadeDeCanais) {
		super(codPlano, descricaoPlano, valorPlano);
		this.quantidadeDeCanais = quantidadeDeCanais;
		
	}

	public int getQuantidadeDeCanais() {
		return quantidadeDeCanais;
	}

	public void setQuantidadeDeCanais(int quantidadeDeCanais) {
		this.quantidadeDeCanais = quantidadeDeCanais;
	}
	
}
