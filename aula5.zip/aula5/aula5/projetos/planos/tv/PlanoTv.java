package aula5.projetos.planos.tv;

import aula5.projetos.planos.Plano;

public abstract class PlanoTv extends Plano {

	public PlanoTv() {
	}

	public PlanoTv(int codPlano, String descricaoPlano, double valorPlano) {
		super(codPlano, descricaoPlano, valorPlano);

	}
}
