package aula5.desafio.calculadora;

import java.util.Scanner;



public class TestaCalculadora {

	public static void main(String[] args) {

		System.out.println("--------------------------Calculadora--------------------------------");

		try (Scanner scanner = new Scanner(System.in)) {

			System.out.println("Digite um numero inteiro:");
			int numeroA = Integer.parseInt(scanner.nextLine());

			System.out.println("Digite o segundo numero inteiro:");
			int numeroB = Integer.parseInt(scanner.nextLine());

			Calculadora calculadora = new Calculadora(numeroA, numeroB);

			System.out.println(
					"\n-----------------------------------Escolha a opera��o---------------------------------------\n");
			System.out.println("1 - SOMA   2 - SUBTRACAO  3 - MULTIPLICACAO   4 - Divisao");
			String operacao = scanner.nextLine();

			if (operacao.equalsIgnoreCase("soma") || operacao.equals("1")) {

				System.out.println("Resultado: " + calculadora.soma());

			} else if (operacao.equalsIgnoreCase("subtracao") || operacao.equals("2")) {

				System.out.println("Resultado: " + calculadora.subtracao());
			}

			else if (operacao.equalsIgnoreCase("multiplicacao") || operacao.equals("3")) {

				System.out.println("Resultado: " + calculadora.multiplicacao());
			}

			else if (operacao.equalsIgnoreCase("divisao") || operacao.equals("4")) {
				if (numeroA == 0 || numeroB == 0) {
					throw new ArithmeticException("Erro opera��o de divisao com ZERO n�o permitida! ");
				}

				System.out.println("Resultado: " + calculadora.divisao());
			}

			else {
				System.out.println("Erro escolha a op��o correta!");
			}
		}
	}

}
