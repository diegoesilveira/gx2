package aula5.desafio.calculadora;

public class CalculadoraNova {

	private int numeroA;
	private int numeroB;
	private String operacao;

	public CalculadoraNova() {
	}
  
	public CalculadoraNova(int numeroA, int numeroB, String operacao) {
		this.numeroA = numeroA;
		this.numeroB = numeroB;
		this.operacao = operacao;
	}

	public double calcula() {

		if (operacao.equals("+")) {
			return numeroA + numeroB;
		} else if (operacao.equals("-")) {
			return numeroA - numeroB;
		} else if (operacao.equals("*")) {
			return numeroA * numeroB;
		} else if (operacao.equals("/")) {

			double numero1 = numeroA;
			double numero2 = numeroB;

			if (numero1 == 0 || numero2 == 0) {
				System.out.println("Erro divis�o por ZERO n�o permitido! ");
			}
			return numero1 / numero2;
		} else {
			System.out.println("Erro digite a opera��o corretamente! ");
		}

		return 0;
	}

}
