package aula5.desafio.calculadora;

public class Calculadora {

	private int numeroA;
	private int numeroB;
		
	public Calculadora() {
	}

	public Calculadora(int numeroA, int numeroB) {
		this.numeroA = numeroA;
		this.numeroB = numeroB;

	}
	
	public double soma() {
		return numeroA + numeroB;

	}

	public double subtracao() {
		return numeroA - numeroB;
	}

	public double multiplicacao() {
		return numeroA * numeroB;
	}

	public double divisao() {
		double numero1 = this.numeroA;
		double numero2 = this.numeroB;
		return numero1 / numero2;
	}
}
