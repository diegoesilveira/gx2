package aula5.desafio.calculadora;

public class TestaCalculadoraNova {

	public static void main(String[] args) {
		
		CalculadoraNova calc = new CalculadoraNova(100,200, "/");
		System.out.println(calc.calcula());
	}
}
