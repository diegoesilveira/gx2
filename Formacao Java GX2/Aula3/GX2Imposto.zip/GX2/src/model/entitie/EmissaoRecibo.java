package model.entitie;

public class EmissaoRecibo {

}
