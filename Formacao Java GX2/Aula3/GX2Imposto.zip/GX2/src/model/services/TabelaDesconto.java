package model.services;

public interface TabelaDesconto {

	public void valorServico(double valor);
}
