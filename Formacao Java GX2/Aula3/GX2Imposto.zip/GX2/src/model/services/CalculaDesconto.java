package model.services;

import model.entitie.Tecnico;

public class CalculaDesconto {
	
	DescontoINSS inss = new DescontoINSS();
	DescontoIR ir = new DescontoIR();
	public Tecnico valorServico = new Tecnico();
	private double calcula;
	
	
	
	public double calculaDesconto() {
		
		return calcula = (valorServico.getValorServico() - inss.getValorDescontoINSS()) - ir.getValorDescontoIR();
	
			
	}
	

}
