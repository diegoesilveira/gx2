package application;

import java.util.InputMismatchException;
import java.util.Scanner;

import model.entitie.Tecnico;
import model.services.CalculaDesconto;
import model.services.DescontoINSS;
import model.services.DescontoIR;

public class App {
	
	public static void main(String[] args) {
		
		CalculaDesconto calculaDesconto = new CalculaDesconto();
		DescontoINSS inss = new DescontoINSS();
		DescontoIR ir = new DescontoIR();
		
		try(Scanner sc = new Scanner(System.in)){
			
			System.out.println("Digite seu nome: \n");
			String nome = sc.nextLine();
			
			System.out.println("Digite seu endereco: \n");
			String endereco = sc.nextLine();
			
			System.out.println("Digite seu CPF: \n");
			String cpf = sc.nextLine();
			
			System.out.println("Digite a Matricula de INSS: \n");
			String matriculaINSS = sc.nextLine();
			
			System.out.println("Digite o valor do servico cobrado: \n");
			Double valorServico = Double.parseDouble(sc.nextLine());		
			Tecnico solitaDados = new Tecnico(nome, endereco, cpf, matriculaINSS, valorServico);
			
			System.out.println(solitaDados.getNome());
			System.out.println(solitaDados.getEndereco());
			System.out.println(solitaDados.getCpf());
			System.out.println(solitaDados.getMatriculaINSS());
			System.out.println(solitaDados.getValorServico());
			
			calculaDesconto.calculaDesconto();
			inss.valorServico(solitaDados.getValorServico());
			ir.valorServico(solitaDados.getValorServico());
			
			System.out.println("Valor INSS: " + inss.getValorDescontoINSS());
			System.out.println("Valor IR: " + ir.getValorDescontoIR());
			
			System.out.println("Valor Liquido: " + calculaDesconto.calculaDesconto());
			
			
		}
		catch(InputMismatchException e) {
			e.printStackTrace();
			
		}
		
			
		
	}
		
	
	
	
	

}
