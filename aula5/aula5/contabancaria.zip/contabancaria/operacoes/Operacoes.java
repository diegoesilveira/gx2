package aula5.contabancaria.operacoes;


public interface Operacoes {
			
	public void depositar(double valor);
	public void transferir(double valor);
	public void sacar(double valor);
	
	
	
	
	
	

}
