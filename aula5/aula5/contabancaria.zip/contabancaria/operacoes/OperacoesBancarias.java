package aula5.contabancaria.operacoes;

import aula5.contabancaria.clientes.Cliente;
import aula5.contabancaria.contas.Conta;
import aula5.contabancaria.contas.ContaCorrente;
import aula5.contabancaria.contas.ContaEspecial;
import aula5.contabancaria.contas.ContaPoupanca;
import aula5.contabancaria.contas.ContaSalario;

public class OperacoesBancarias {
	
	public static void processaOperacao() {
		
		Conta contaCorrente = new ContaCorrente(20, 200, 0.6);
		Conta contaSalario = new ContaSalario(5);
		Conta contaPoupanca = new ContaPoupanca(10);
		Conta contaEspecial = new ContaEspecial(25, 300, 0.10);
		
		Cliente cliente = new Cliente("Diego", "01598906088", contaCorrente);
		
		cliente.getConta().depositar(500);
		cliente.getConta().depositar(500);
		cliente.getConta().depositar(500);
		cliente.getConta().transferir(1400);

		//cliente.getConta().transferir(10);
		
		
		System.out.println("Cliente: " + cliente.getNomeCliente() + "\nSaldo: " + cliente.getConta().getSaldo());

	   //System.out.println("Cliente: " + cliente2.getNomeCliente() + "\nSaldo: " + cliente2.getConta().getSaldo());
		
		Extrato.geraExtrato(cliente);


		
	}
    
    
}
