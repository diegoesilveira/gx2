package aula5.contabancaria.app;

import aula5.contabancaria.operacoes.OperacoesBancarias;

public class TestaConta {

	public static void main(String[] args) {
		
		OperacoesBancarias.processaOperacao();
		
		
		
	}
}
