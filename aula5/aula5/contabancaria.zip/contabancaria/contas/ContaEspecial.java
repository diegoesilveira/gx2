package aula5.contabancaria.contas;

public class ContaEspecial extends Conta{

	public ContaEspecial(double tarifa, int limite, double juros) {
		super(tarifa, limite, juros);
	}

	@Override
	public void depositar(double valor) {
		
	}

	@Override
	public void transferir(double valor) {
		
	}

	@Override
	public void sacar(double valor) {
		
	}
	
	

}
