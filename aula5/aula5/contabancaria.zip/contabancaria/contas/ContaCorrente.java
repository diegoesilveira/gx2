package aula5.contabancaria.contas;


public class ContaCorrente extends Conta{
	
	
	public ContaCorrente(double tarifa, int limite, double juros) {
		super(tarifa, limite, juros);
	}


	@Override
	public void depositar(double valor) {
		calculaOperacao = ((getSaldo() + valor) - getTarifa());
		setSaldo(calculaOperacao);
	}

	@Override
	public void transferir(double valor) {
		if(valor > getSaldo() & valor > getLimite()) {
			System.out.println("Saldo insuficiente para efetuar a transferencia, saldo insuficiente: Saldo: " + getSaldo());
			
		} else {
			calculaOperacao = (getSaldo() - valor - getTarifa());
			setSaldo(calculaOperacao);
		}
	}

	@Override
	public void sacar(double valor) {
		if(valor > getSaldo() & valor > getLimite()) {
			System.out.println("Não foi possivel realizar o saque, saldo insuficiente: Saldo: " + getSaldo());
		} else {
			calculaOperacao = (getSaldo() - valor) - getTarifa();
			setSaldo(calculaOperacao);
			
		}
	}
	
	
	

}
